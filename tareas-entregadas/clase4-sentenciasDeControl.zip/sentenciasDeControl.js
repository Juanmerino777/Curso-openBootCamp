// ejercicio tema 4

//condicional if:
var numeroIf = 10;

if (numeroIf > 0) {
  console.log("El numero es positivo");
}else if (numeroIf < 0) {
  console.log("El numero es negativo");
}else {
  console.log(" El numero es 0");
}


//bucle while:------------------------------------------
var numeroWhile = 0;
while (numeroWhile < 3) {
  numeroWhile++;
  console.log(numeroWhile);
}



// bucle do while:---------------------------------------
var numeroDoWhile = 0;
  do {
    numeroDoWhile++;
    console.log(numeroDoWhile);
  }while (numeroDoWhile < 1) 
  


  // bucle for:-----------------------------------------
  for  (var numeroFor = 0; numeroFor <= 3; numeroFor++) {
    console.log(numeroFor);
  }


  //switch:--------------------------------------
  var estacion = "otoño";
  switch(estacion) {
    case "otoño":
    console.log("estamos en otoño");
    break;
    case "verano":
    console.log("estamos en verano");
    break;
    case "invierno":
    console.log("estamos en invierno");
    break;
    case "primavera":
    console.log("estamos en primavera");
    break;
    default:
      console.log("no es  estacion");
  }